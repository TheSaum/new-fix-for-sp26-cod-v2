# CoD: Modern Warfare 4 SP — one-click fix

**File:** `Fix-CoD-MW4-SP.bat`
Put it in the game folder (the one with `cod.exe` and the `sp26` folder) and double-click it.

It does everything automatically:

1. Asks for Administrator rights (UAC).
2. Finds the game folder (works even if you run it from Downloads).
3. Installs + starts the `Randgrid` anti-cheat kernel driver
   (service `atvi-randgrid_sr_offline`).
4. Replaces the corrupted `!start_sp26.bat` with a working one
   (the original is saved as `!start_sp26.bat.bak`).
5. Rebuilds the desktop shortcut.
6. Starts the game **elevated** and keeps the driver up until you quit.

Use `Fix-CoD-MW4-SP.bat /test` to only check the driver without launching.

---

## Reddit post (copy/paste)

**Title:** `FIX: CoD MW4 SP (cod26 / rex_sp offline v2) won't start, or closes after 2 seconds`

**Body:**

> If the game never opens, or it opens and closes after ~2 seconds with no error,
> no crash dump and nothing in Event Viewer, the problem is almost always the
> anti-cheat driver service, and the repack's launcher is what breaks it.
>
> **1. Check the service**
>
> Open CMD and run:
>
> ```
> sc query atvi-randgrid_sr_offline
> ```
>
> `FAILED 1060` means it is not installed. That is your bug.
>
> **2. Check `!start_sp26.bat`**
>
> Open it in Notepad. In a lot of repacks it looks like this:
>
> ```
> cd /d "%\~dp0"
> powershell -Command "Start-Process -FilePath '%\~f0' ... -Verb RunAs"
> set DRIVERPATH=%\~dp0%DRIVERFILE%
> ```
>
> It must be `%~dp0` and `%~f0`. Because of that one extra backslash:
>
> - `cd` fails, so the script never enters the game folder
> - the self-elevation line launches a path that does not exist,
>   so double-clicking the file does nothing at all
> - `DRIVERPATH` becomes `%\~dp0Randgrid.sys`, so `sc create` fails
> - the kernel driver `Randgrid.sys` is never registered
>
> The game needs that driver. Without it `sp26-cod.exe` shows the Ricochet
> splash and quits (exit code 0, ~2 seconds).
>
> **3. Fix it**
>
> Either fix the three `%\~` into `%~` by hand, or use the attached
> `Fix-CoD-MW4-SP.bat`. Put it in the game folder, double-click it, click Yes
> on UAC. It installs and starts the driver, replaces the broken bat, rebuilds
> the desktop shortcut and launches the game.
>
> **4. Important**
>
> The game has to run **as Administrator**. If you launch `sp26-cod.exe`
> directly you will get a black `rex_sp` window saying
>
> ```
> The token does not have the specified privilege.
> ```
>
> and it closes. Always start it through the .bat / desktop shortcut.
>
> **5. Manual version (no script)**
>
> Open CMD **as Administrator**, `cd` to the game folder, then:
>
> ```
> icacls "Randgrid.sys" /grant "NT AUTHORITY\SYSTEM:(RX)" /grant "BUILTIN\Administrators:(F)"
> sc create atvi-randgrid_sr_offline type= kernel binPath= "D:\Call of Duty - Modern Warfare 4\Randgrid.sys"
> sc start atvi-randgrid_sr_offline
> sc query atvi-randgrid_sr_offline
> ```
>
> You want `STATE : 4  RUNNING`. Then start
> `sp26\sp26-cod.exe hdeyguxs3zaumvlgvybm2vyc` with working directory `sp26`.
>
> Notes:
> - `sc create` needs the space in `binPath= "..."`. Without it, it fails silently.
> - The shortcut on the Public Desktop points to the `.bat`, not to the game,
>   so if the `.bat` is broken you will never see the game.
> - If `cod26\main\extccs\31` is empty, your repack is missing the CCS patch
>   files. Run the repack's integrity check / re-hash.
> - If the driver refuses to start, check Windows Security > Protection history
>   and make sure `Randgrid.sys` was not quarantined.
