@echo off
setlocal EnableExtensions
title Call of Duty - Modern Warfare 4 SP  ^|  One-Click Fix
color 0A

rem ===========================================================================
rem  One-click fix + launcher for:
rem      Call of Duty: Modern Warfare 4 (cod26 / "rex_sp offline v2")
rem
rem  What it does:
rem    1. Elevates itself (the kernel driver needs admin).
rem    2. Finds the game folder.
rem    3. Installs + starts the Randgrid anti-cheat kernel driver
rem       (service "atvi-randgrid_sr_offline"). Without it the game
rem       shows the Ricochet splash and closes after ~2 seconds.
rem    4. Replaces the corrupted "!start_sp26.bat" with this working file
rem       (the original is kept as "!start_sp26.bat.bak").
rem    5. (Re)creates the desktop shortcut.
rem    6. Launches the game and keeps the driver alive until you quit.
rem
rem  Just double-click it. Use  /test  to only verify the driver.
rem ===========================================================================

set "TESTMODE="
if /i "%~1"=="/test" set "TESTMODE=1"
if /i "%~2"=="/test" set "TESTMODE=1"

rem ---------------------------------------------------------------- 1. elevate
if /i "%~1"=="--elevated" goto :elevated
fltmc >nul 2>&1
if errorlevel 1 (
    echo.
    echo   Requesting administrator rights...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -ArgumentList '--elevated %*' -WorkingDirectory '%~dp0' -Verb RunAs"
    exit /b
)
:elevated

echo.
echo   ============================================================
echo      Call of Duty: Modern Warfare 4 SP  -  One-Click Fix
echo   ============================================================
echo.

rem ------------------------------------------------------------ 2. find game
set "GAMEDIR=%~dp0"
set "GAMEEXE="
if exist "%GAMEDIR%sp26\sp26-cod.exe" set "GAMEEXE=%GAMEDIR%sp26\sp26-cod.exe"
if not defined GAMEEXE if exist "%GAMEDIR%cod.exe" set "GAMEEXE=%GAMEDIR%cod.exe"

if not defined GAMEEXE (
    for %%D in (C D E F G H I J K) do (
        if exist "%%D:\Call of Duty - Modern Warfare 4\sp26\sp26-cod.exe" (
            set "GAMEDIR=%%D:\Call of Duty - Modern Warfare 4\"
            set "GAMEEXE=%%D:\Call of Duty - Modern Warfare 4\sp26\sp26-cod.exe"
        )
    )
)

if not defined GAMEEXE (
    echo   [X] Game folder not found.
    echo.
    echo   Put this file inside the game folder ^(the one that contains
    echo   cod.exe and the sp26 folder^) and run it again.
    echo.
    pause
    exit /b 1
)

echo   Game folder : %GAMEDIR%

rem -------------------------------------------------------- 3. anti-cheat drv
set "DRIVERFILE=%GAMEDIR%Randgrid.sys"
set "DRIVERNAME=atvi-randgrid_sr_offline"

if not exist "%DRIVERFILE%" (
    echo.
    echo   [X] Randgrid.sys is missing from the game folder.
    echo       Without it the game closes a few seconds after launch.
    echo       Re-extract / re-download the crack files.
    echo.
    pause
    exit /b 1
)

icacls "%DRIVERFILE%" /grant "NT AUTHORITY\SYSTEM:(RX)" /grant "BUILTIN\Administrators:(F)" >nul 2>&1

sc query %DRIVERNAME% >nul 2>&1
if errorlevel 1 (
    echo   Installing anti-cheat driver...
    sc.exe create %DRIVERNAME% type= kernel binPath= "%DRIVERFILE%" >nul 2>&1
)

sc start %DRIVERNAME% >nul 2>&1
sc query %DRIVERNAME% | find /i "RUNNING" >nul
if errorlevel 1 (
    echo.
    echo   [X] The anti-cheat driver could not be started.
    echo.
    echo   Possible causes:
    echo     - Windows Defender / antivirus blocked Randgrid.sys
    echo     - Driver signature enforcement / Secure Boot is blocking it
    echo     - The file is corrupted ^(check its digital signature^)
    echo.
    sc query %DRIVERNAME%
    echo.
    pause
    exit /b 1
)
echo   [OK] Anti-cheat driver is installed and RUNNING.

rem ------------------------------------------------ 4. replace the broken bat
if /i not "%~f0"=="%GAMEDIR%!start_sp26.bat" (
    if exist "%GAMEDIR%!start_sp26.bat" (
        copy /y "%GAMEDIR%!start_sp26.bat" "%GAMEDIR%!start_sp26.bat.bak" >nul 2>&1
    )
    copy /y "%~f0" "%GAMEDIR%!start_sp26.bat" >nul 2>&1
    echo   [OK] !start_sp26.bat replaced ^(backup: !start_sp26.bat.bak^).
)

rem ------------------------------------------------------- 5. desktop shortcut
powershell -NoProfile -Command "$p=[Environment]::GetFolderPath('CommonDesktopDirectory')+'\Call of Duty - Modern Warfare 4.lnk'; $s=(New-Object -ComObject WScript.Shell).CreateShortcut($p); $s.TargetPath='%GAMEDIR%!start_sp26.bat'; $s.WorkingDirectory='%GAMEDIR%'; $s.IconLocation='%GAMEDIR%cod.exe,0'; $s.Save()" >nul 2>&1
if exist "%PUBLIC%\Desktop\Call of Duty - Modern Warfare 4.lnk" echo   [OK] Desktop shortcut is ready.

rem ------------------------------------------------------------ 6. extra check
if exist "%GAMEDIR%cod26\main\extccs\31" (
    dir /b "%GAMEDIR%cod26\main\extccs\31" 2>nul | findstr /r "." >nul
    if errorlevel 1 (
        echo.
        echo   [i] Note: cod26\main\extccs\31 is empty. Some repacks are
        echo       missing these patch files. If the game still closes,
        echo       re-run the repack's integrity check.
    )
)

if defined TESTMODE (
    echo.
    echo   Test mode: everything is OK, game launch skipped.
    echo.
    pause
    exit /b 0
)

rem ---------------------------------------------------------------- 7. launch
echo.
echo   Starting the game...
if /i "%GAMEEXE%"=="%GAMEDIR%cod.exe" (
    start "" /d "%GAMEDIR%" "%GAMEEXE%"
    set "IMAGENAME=cod.exe"
) else (
    start "" /d "%GAMEDIR%sp26" "%GAMEEXE%" hdeyguxs3zaumvlgvybm2vyc
    set "IMAGENAME=sp26-cod.exe"
)

timeout /t 10 /nobreak >nul
tasklist /fi "imagename eq %IMAGENAME%" 2>nul | find /i "%IMAGENAME%" >nul
if errorlevel 1 (
    echo.
    echo   [X] The game closed immediately.
    echo.
    echo   1. Did Windows ask for Administrator rights and you clicked No?
    echo      The game needs an elevated token. Run this file again and
    echo      click Yes.
    echo   2. Open Windows Security ^> Protection history and allow anything
    echo      it blocked inside the sp26 folder.
    echo   3. If the black "rex_sp" window says
    echo      "The token does not have the specified privilege.",
    echo      the game was not started elevated - always use this file
    echo      or the desktop shortcut, never sp26-cod.exe directly.
    echo.
    pause
    exit /b 1
)

echo   [OK] Game is running. Leave this window open.
echo        It closes automatically when you quit the game.
echo.

:wait
timeout /t 3 /nobreak >nul
tasklist /fi "imagename eq %IMAGENAME%" 2>nul | find /i "%IMAGENAME%" >nul
if not errorlevel 1 goto wait

echo   Game closed. The anti-cheat driver stays installed and stopped.
sc stop %DRIVERNAME% >nul 2>&1
echo   Done.
timeout /t 3 /nobreak >nul
exit /b 0
